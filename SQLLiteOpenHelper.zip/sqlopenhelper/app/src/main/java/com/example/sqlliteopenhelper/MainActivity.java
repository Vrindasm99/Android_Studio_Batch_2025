package com.example.sqlliteopenhelper;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText e_name, e_contact, e_address;
    Button b_add, b_del, b_edit, b_view;
    SQLLite sqlLite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e_name = findViewById(R.id.name);
        e_contact = findViewById(R.id.contact);
        e_address = findViewById(R.id.address);

        b_add = findViewById(R.id.b_ins);
        b_edit = findViewById(R.id.b_edit);
        b_del = findViewById(R.id.b_del);
        b_view = findViewById(R.id.b_view);

        sqlLite = new SQLLite(this);

    }
}