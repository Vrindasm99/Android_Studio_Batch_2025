package com.example.listviewexample;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;


import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {


    ListView list;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listview);
        arrayList = new ArrayList<>();
        arrayList.add("Mango");
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Guava");
        arrayList.add("Grapes");
        arrayList.add("Pineapple");
        arrayList.add("Orange");
        arrayList.add("Kiwi");

        arrayAdapter = new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                arrayList
        );

        list.setAdapter(arrayAdapter);

    }
}